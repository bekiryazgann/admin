(function(){

})()<?php /**PATH /Users/bekir/Desktop/admin/themes/admin/views/web-builder/components/footer/footer-1/js.blade.php ENDPATH**/ ?>