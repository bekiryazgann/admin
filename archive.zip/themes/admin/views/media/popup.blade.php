<div class="modal fade selectMedia"
     id="selectMedia"
     tabindex="-1"
     aria-labelledby="selectMedia"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg two-factor-auth">
        <div class="modal-content">
            <div class="modal-header bg-transparent" style="border-bottom: 1px solid #3b4253;">
                <h3 class="modal-title"> Medya </h3>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body pb-5 px-sm-5 mx-50 overflow-scroll h-100"
                 id="loaderArea"
                 style="height: calc(100vh / 2) !important">
            </div>
            <div class="modal-footer" style="display: flex;"></div>
        </div>
    </div>
</div>