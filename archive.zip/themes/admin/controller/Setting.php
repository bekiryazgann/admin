<?php
	
	namespace themes\admin\controller;
	
	use Core\Controller;
	
	class Setting extends Controller
	{
		public function systemSettings(): string
        {
            return $this->view('settings.system-settings');
        }
	}