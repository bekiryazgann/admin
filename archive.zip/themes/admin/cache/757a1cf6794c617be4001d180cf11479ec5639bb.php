(function(){

})()<?php /**PATH /Users/bekir/Desktop/admin/themes/admin/views/web-builder/components/header/header-5/js.blade.php ENDPATH**/ ?>