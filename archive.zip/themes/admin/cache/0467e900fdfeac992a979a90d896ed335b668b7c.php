<?php $__env->startSection('title', trans('Menu Yönetimi')); ?>
<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title"> Menüler </h3>
                </div>
                <div class="card-body">
                    <div class="row">
                        <div class="col-6">
                            <a class="card shadow-none border cursor-pointer btn btn-primary">
                                <div class="card-body d-flex align-items-center justify-content-center">
                                    Header Menü
                                </div>
                            </a>
                        </div>
                        <div class="col-6">
                            <a class="card shadow-none border cursor-pointer btn btn-primary">
                                <div class="card-body d-flex align-items-center justify-content-center">
                                    Footer Menü
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bekir/Desktop/admin/themes/admin/views/design-settings/menuSettings.blade.php ENDPATH**/ ?>