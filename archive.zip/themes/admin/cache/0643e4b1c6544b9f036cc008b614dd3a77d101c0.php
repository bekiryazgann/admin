(function(){

})()<?php /**PATH /Users/bekir/Desktop/admin/themes/admin/views/web-builder/components/page-title/page-title-1/js.blade.php ENDPATH**/ ?>