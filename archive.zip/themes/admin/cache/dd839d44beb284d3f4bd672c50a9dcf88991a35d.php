<?php $__env->startSection('title', trans('Sistem Ayarları')); ?>
<?php $__env->startSection('content'); ?>
    <div class="d-flex align-items-center justify-content-center" style="height: calc(100vh - 150px)">
        <div class="card h-auto w-100 p-3">
            <div class="card-body">
                <div class="row">
                    <a class="col-4 d-flex align-items-center p-2 cursor-pointer"
                       href="<?php echo e(siteUrl('settings/system-settings/corporate-information')); ?>">
                        <i class="far fa-file me-2 font-medium-5 text-dark"></i>
                        <div class="d-flex flex-column">
                            <h3 style="color: #6e6b7b;" class="mb-0">Kurumsal Bilgiler</h3>
                            <span style="color: #676d7d;"> Kurumsal bilgileriniz düzenleyin. </span>
                        </div>
                    </a>
                    <?php if(1 < 0): ?>
                        <!-- Döviz Ayarları -->
                        <a class="col-4 d-flex align-items-center p-2 cursor-pointer"
                           href="<?php echo e(siteUrl('settings/system-settings/currency-settings')); ?>">
                            <i class="far fa-file me-2 font-medium-5 text-dark"></i>
                            <div class="d-flex flex-column">
                                <h3 style="color: #6e6b7b;" class="mb-0">Döviz Ayarları</h3>
                                <span style="color: #676d7d;"> Döviz kurlarını güncelleyin ve yönetin. </span>
                            </div>
                        </a>
                    <?php endif; ?>
                    <a class="col-4 d-flex align-items-center p-2 cursor-pointer"
                       href="<?php echo e(siteUrl('settings/system-settings/tax-settings')); ?>">
                        <i class="far fa-file me-2 font-medium-5 text-dark"></i>
                        <div class="d-flex flex-column">
                            <h3 style="color: #6e6b7b;" class="mb-0">Vergi Ayarları</h3>
                            <span style="color: #676d7d;"> Satış kapsamınıza uygun vergilerinizi ayarlayın. </span>
                        </div>
                    </a>
                    <div class="col-4 d-flex align-items-center p-2 cursor-pointer">
                        <i class="far fa-file me-2 font-medium-5 text-dark"></i>
                        <div class="d-flex flex-column">
                            <h3 style="color: #6e6b7b;" class="mb-0">Kullanıcılar</h3>
                            <span style="color: #676d7d;"> Web sitenize erişebilecek kullanıcıları düzenleyin. </span>
                        </div>
                    </div>
                    <div class="col-4 d-flex align-items-center p-2 cursor-pointer">
                        <i class="far fa-file me-2 font-medium-5 text-dark"></i>
                        <div class="d-flex flex-column">
                            <h3 style="color: #6e6b7b;" class="mb-0">Mağaza Ayarları</h3>
                            <span style="color: #676d7d;"> Mağazanızın özellik ayarlarını düzenleyin. </span>
                        </div>
                    </div>
                    <div class="col-4 d-flex align-items-center p-2 cursor-pointer">
                        <i class="far fa-file me-2 font-medium-5 text-dark"></i>
                        <div class="d-flex flex-column">
                            <h3 style="color: #6e6b7b;" class="mb-0">Dil Ayarları</h3>
                            <span style="color: #676d7d;"> Sitenizin gösterim dilini düzenleyin. </span>
                        </div>
                    </div>
                    <div class="col-4 d-flex align-items-center p-2 cursor-pointer">
                        <i class="far fa-file me-2 font-medium-5 text-dark"></i>
                        <div class="d-flex flex-column">
                            <h3 style="color: #6e6b7b;" class="mb-0">Optimizasyonlar</h3>
                            <span style="color: #676d7d;"> Web sitenizin önbelleğini temizleyin. </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bekir/Desktop/admin/themes/admin/views/settings/system-settings.blade.php ENDPATH**/ ?>