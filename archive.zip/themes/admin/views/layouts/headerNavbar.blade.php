<div class="navbar-header">
    <ul class="nav navbar-nav flex-row">
        <li class="nav-item me-auto">
            @includeIf('layouts.logoArea')
        </li>
        <li class="nav-item nav-toggle">
            <a class="nav-link modern-nav-toggle pe-0"
               data-bs-toggle="collapse">
                <i class="d-block d-xl-none text-primary toggle-icon font-medium-4"
                   data-feather="x"></i>
                <i class="d-none d-xl-block collapse-toggle-icon font-medium-4 text-primary"
                   data-feather="chevron-right" data-ticon="disc"></i>
            </a>
        </li>
    </ul>
</div>
<div class="shadow-bottom"></div>