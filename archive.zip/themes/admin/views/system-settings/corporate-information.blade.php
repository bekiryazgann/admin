@extends('layouts.layout')
@section('title', trans('Kurumsal Bilgiler'))
@section('content')
    <form method="post" enctype="multipart/form-data">
        <div class="card bg-transparent box-shadow-0">
            <div class="card-header p-0">
                <h3 class="m-0 font-medium-4 p-0">@trans(Kurumsal Bilgiler)</h3>
                <div>
                    <button class="btn btn-primary" type="submit">@trans(Kaydet)</button>
                    <button class="btn btn-outline-primary" type="reset">@trans(Vazgeç)</button>
                </div>
            </div>
        </div>
        <div class="alert alert-primary">
            <div class="alert-body">
                Bu bilgiler faturalarınızda, müşteri destek süreçlerinde ve Socore ile iletişim süreçlerinde kullanılacaktır.
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="d-flex mb-2">
                        <a href="#" class="me-25">
                            <img src="//192.168.1.156:8081/media/no-image.webp"
                                 id="account-upload-img"
                                 class="uploadedAvatar rounded me-50"
                                 alt="profile image"
                                 width="100"
                                 height="100">
                        </a>
                        <div class="d-flex align-items-end mt-75 ms-1">
                            <form id="ppForm">
                                <label for="brand-logo"
                                       class="btn btn-sm btn-primary mb-75 me-75 waves-effect waves-float waves-light"
                                       data-bs-toggle="tooltip"
                                       data-bs-placement="right"
                                       data-bs-original-title="Müşterilerilerinize gönderdiğiniz e-postalarda, raporlarınızda ve dışa aktardığınız belgelerde bu logo görünecektir.">Logo Yükle</label>
                                <input type="file" id="brand-logo"
                                       accept="image/*"
                                       name="brand-logo"
                                       hidden>
                            </form>
                        </div>
                    </div>
                    @getError('brand-logo')

                    <h3 class="col-12 card-title font-medium-5">@trans(Satıcı Bilgileri)</h3>
                    <div class="col-12">
                        <div class="mb-1 row">
                            <label for="company-name"
                                   class="col-sm-12 col-form-label-lg">@trans(Şirket Adı)</label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="company-name"
                                       name="company-name"
                                       placeholder="@trans(Socore Dijital Sistemler LTD. ŞTİ.)">
                            </div>
                            @getError('company-name')
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="mb-1 row">
                            <label for="tax-id"
                                   class="col-sm-12 col-form-label-lg">@trans(Vergi Numarası)</label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="tax-id"
                                       name="tax-id"
                                       placeholder="@trans(4953469449)">
                            </div>
                            @getError('tax-id')
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="mb-1 row">
                            <label for="tax-office"
                                   class="col-sm-12 col-form-label-lg">@trans(Vergi Dairesi)</label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="tax-office"
                                       name="tax-office"
                                       placeholder="@trans(Ilıca Vd.)">
                            </div>
                            @getError('tax-office')
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-1 row">
                            <label for="address"
                                   class="col-sm-12 col-form-label-lg">@trans(Adres)</label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="address"
                                       name="address"
                                       placeholder="@trans(Sahil Mercan Fish, 11, Turgut Özal Bulvarı)">
                            </div>
                            @getError('address')
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="mb-1 row">
                            <label for="district"
                                   class="col-sm-12 col-form-label-lg">@trans(İlçe)</label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="district"
                                       name="district"
                                       placeholder="@trans(Küçükçekmece)">
                            </div>
                            @getError('district')
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="mb-1 row">
                            <label for="province"
                                   class="col-sm-12 col-form-label-lg">@trans(İl)</label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="province"
                                       name="province"
                                       placeholder="@trans(İstanbul)">
                            </div>
                            @getError('province')
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="mb-1 row">
                            <label for="country"
                                   class="col-sm-12 col-form-label-lg">@trans(Ülke)</label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="country"
                                       name="country"
                                       placeholder="@trans(Türkiye)">
                            </div>
                            @getError('country')
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="mb-1 row">
                            <label for="phone"
                                   class="col-sm-12 col-form-label-lg">@trans(Telefon)</label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="phone"
                                       name="phone"
                                       placeholder="@trans(+905679825340)">
                            </div>
                            @getError('phone')
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="mb-1 row">
                            <label for="email"
                                   class="col-sm-12 col-form-label-lg">@trans(E-posta)</label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="email"
                                       name="email"
                                       placeholder="@trans(info@socore.app)">
                            </div>
                            @getError('email')
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card bg-transparent box-shadow-0">
            <div class="card-header p-0">
                <i class="card-title"></i>
                <div>
                    <button class="btn btn-primary" type="submit">@trans(Kaydet)</button>
                    <button class="btn btn-outline-primary" type="reset">@trans(Vazgeç)</button>
                </div>
            </div>
        </div>
    </form>
@endsection