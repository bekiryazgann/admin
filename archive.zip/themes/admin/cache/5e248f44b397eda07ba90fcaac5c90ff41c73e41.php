<?php $__env->startSection('title', trans('Kurumsal Bilgiler')); ?>
<?php $__env->startSection('content'); ?>
    <form method="post" enctype="multipart/form-data">
        <div class="card bg-transparent box-shadow-0">
            <div class="card-header p-0">
                <h3 class="m-0 font-medium-4 p-0"><?php echo trans("Kurumsal Bilgiler") ?></h3>
                <div>
                    <button class="btn btn-primary" type="submit"><?php echo trans("Kaydet") ?></button>
                    <button class="btn btn-outline-primary" type="reset"><?php echo trans("Vazgeç") ?></button>
                </div>
            </div>
        </div>
        <div class="alert alert-primary">
            <div class="alert-body">
                Bu bilgiler faturalarınızda, müşteri destek süreçlerinde ve Socore ile iletişim süreçlerinde kullanılacaktır.
            </div>
        </div>
        <div class="card">
            <div class="card-body">
                <div class="row">
                    <div class="d-flex mb-2">
                        <a href="#" class="me-25">
                            <img src="//192.168.1.156:8081/media/no-image.webp"
                                 id="account-upload-img"
                                 class="uploadedAvatar rounded me-50"
                                 alt="profile image"
                                 width="100"
                                 height="100">
                        </a>
                        <div class="d-flex align-items-end mt-75 ms-1">
                            <form id="ppForm">
                                <label for="brand-logo"
                                       class="btn btn-sm btn-primary mb-75 me-75 waves-effect waves-float waves-light"
                                       data-bs-toggle="tooltip"
                                       data-bs-placement="right"
                                       data-bs-original-title="Müşterilerilerinize gönderdiğiniz e-postalarda, raporlarınızda ve dışa aktardığınız belgelerde bu logo görünecektir.">Logo Yükle</label>
                                <input type="file" id="brand-logo"
                                       accept="image/*"
                                       name="brand-logo"
                                       hidden>
                            </form>
                        </div>
                    </div>
                    <?php if (isset($errors['brand-logo'])): ?><div class="row"><div class="col-12"><div class="alert alert-danger mt-1" style="padding: 10px 12px"><?=$errors['brand-logo'][0]?></div></div></div><?php endif; ?>

                    <h3 class="col-12 card-title font-medium-5"><?php echo trans("Satıcı Bilgileri") ?></h3>
                    <div class="col-12">
                        <div class="mb-1 row">
                            <label for="company-name"
                                   class="col-sm-12 col-form-label-lg"><?php echo trans("Şirket Adı") ?></label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="company-name"
                                       name="company-name"
                                       placeholder="<?php echo trans("Socore Dijital Sistemler LTD. ŞTİ.") ?>">
                            </div>
                            <?php if (isset($errors['company-name'])): ?><div class="row"><div class="col-12"><div class="alert alert-danger mt-1" style="padding: 10px 12px"><?=$errors['company-name'][0]?></div></div></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="mb-1 row">
                            <label for="tax-id"
                                   class="col-sm-12 col-form-label-lg"><?php echo trans("Vergi Numarası") ?></label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="tax-id"
                                       name="tax-id"
                                       placeholder="<?php echo trans("4953469449") ?>">
                            </div>
                            <?php if (isset($errors['tax-id'])): ?><div class="row"><div class="col-12"><div class="alert alert-danger mt-1" style="padding: 10px 12px"><?=$errors['tax-id'][0]?></div></div></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="mb-1 row">
                            <label for="tax-office"
                                   class="col-sm-12 col-form-label-lg"><?php echo trans("Vergi Dairesi") ?></label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="tax-office"
                                       name="tax-office"
                                       placeholder="<?php echo trans("Ilıca Vd.") ?>">
                            </div>
                            <?php if (isset($errors['tax-office'])): ?><div class="row"><div class="col-12"><div class="alert alert-danger mt-1" style="padding: 10px 12px"><?=$errors['tax-office'][0]?></div></div></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-12">
                        <div class="mb-1 row">
                            <label for="address"
                                   class="col-sm-12 col-form-label-lg"><?php echo trans("Adres") ?></label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="address"
                                       name="address"
                                       placeholder="<?php echo trans("Sahil Mercan Fish, 11, Turgut Özal Bulvarı") ?>">
                            </div>
                            <?php if (isset($errors['address'])): ?><div class="row"><div class="col-12"><div class="alert alert-danger mt-1" style="padding: 10px 12px"><?=$errors['address'][0]?></div></div></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="mb-1 row">
                            <label for="district"
                                   class="col-sm-12 col-form-label-lg"><?php echo trans("İlçe") ?></label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="district"
                                       name="district"
                                       placeholder="<?php echo trans("Küçükçekmece") ?>">
                            </div>
                            <?php if (isset($errors['district'])): ?><div class="row"><div class="col-12"><div class="alert alert-danger mt-1" style="padding: 10px 12px"><?=$errors['district'][0]?></div></div></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="mb-1 row">
                            <label for="province"
                                   class="col-sm-12 col-form-label-lg"><?php echo trans("İl") ?></label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="province"
                                       name="province"
                                       placeholder="<?php echo trans("İstanbul") ?>">
                            </div>
                            <?php if (isset($errors['province'])): ?><div class="row"><div class="col-12"><div class="alert alert-danger mt-1" style="padding: 10px 12px"><?=$errors['province'][0]?></div></div></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-4">
                        <div class="mb-1 row">
                            <label for="country"
                                   class="col-sm-12 col-form-label-lg"><?php echo trans("Ülke") ?></label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="country"
                                       name="country"
                                       placeholder="<?php echo trans("Türkiye") ?>">
                            </div>
                            <?php if (isset($errors['country'])): ?><div class="row"><div class="col-12"><div class="alert alert-danger mt-1" style="padding: 10px 12px"><?=$errors['country'][0]?></div></div></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="mb-1 row">
                            <label for="phone"
                                   class="col-sm-12 col-form-label-lg"><?php echo trans("Telefon") ?></label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="phone"
                                       name="phone"
                                       placeholder="<?php echo trans("+905679825340") ?>">
                            </div>
                            <?php if (isset($errors['phone'])): ?><div class="row"><div class="col-12"><div class="alert alert-danger mt-1" style="padding: 10px 12px"><?=$errors['phone'][0]?></div></div></div><?php endif; ?>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="mb-1 row">
                            <label for="email"
                                   class="col-sm-12 col-form-label-lg"><?php echo trans("E-posta") ?></label>
                            <div class="col-12">
                                <input type="text"
                                       class="form-control"
                                       id="email"
                                       name="email"
                                       placeholder="<?php echo trans("info@socore.app") ?>">
                            </div>
                            <?php if (isset($errors['email'])): ?><div class="row"><div class="col-12"><div class="alert alert-danger mt-1" style="padding: 10px 12px"><?=$errors['email'][0]?></div></div></div><?php endif; ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="card bg-transparent box-shadow-0">
            <div class="card-header p-0">
                <i class="card-title"></i>
                <div>
                    <button class="btn btn-primary" type="submit"><?php echo trans("Kaydet") ?></button>
                    <button class="btn btn-outline-primary" type="reset"><?php echo trans("Vazgeç") ?></button>
                </div>
            </div>
        </div>
    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bekir/Desktop/admin/themes/admin/views/system-settings/corporate-information.blade.php ENDPATH**/ ?>