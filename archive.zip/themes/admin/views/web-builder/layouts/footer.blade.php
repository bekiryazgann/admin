<footer class="footer footer-static footer-light">
    <p class="clearfix mb-0">
        <span class="float-md-start d-block d-md-inline-block mt-25">
            @trans(TELİF HAKKI) &copy; {{carbon()->year}} <a class="ms-25" href="https://socore.app/" target="_blank">@trans(Socore Dijital Sistemler)</a>
        </span>
        <span class="float-md-end d-none d-md-block">
            @trans(Sürüm)
            1.2.0
        </span>
    </p>
</footer>