<section class="bg-gray-200 py-2">
    <div class="container mx-auto">
        <p class="text-blue-500 text-center">{{$data['text']}}</p>
    </div>
</section>