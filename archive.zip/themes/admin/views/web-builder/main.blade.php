@extends('web-builder.layouts.layout')
@section('title', 'Tasarımı Özelleştir')

@section('content')
    <div class="iframe-container" style="width: 100%;transition: 400ms width;">
    </div>
@endsection