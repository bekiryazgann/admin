@extends('layouts.layout')
@section('title', trans('Müşteriler'))
@section('content')
    B2b Müşteriler
@endsection