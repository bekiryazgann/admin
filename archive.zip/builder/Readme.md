# Basic CSS JavaScript Minifier Tool



# 🚀 Quick start

Firstly paste the code below in your terminal to copy this repo
``` 
git clone https://github.com/socoreapp/js-css-minifier-tool 
```