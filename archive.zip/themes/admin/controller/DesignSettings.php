<?php
	
	namespace themes\admin\controller;
	
	use Core\Controller;
	use Illuminate\Database\Capsule\Manager;
	use Symfony\Component\HttpFoundation\Request;
    use Symfony\Component\HttpFoundation\Response;

    class DesignSettings extends Controller
	{
		public function menuSettings(): string
		{
			return $this->view('design-settings.menuSettings');
		}

        public function editMenuSettings($slug, Request $request, Response $response):string
        {
            if ($slug == 'header' || $slug == 'footer'){


                if ($request->getMethod() == 'POST'){
                    if(xssToken()->isVerify()){
                        $status = Manager::table('menu')
                            ->where('license', auth()->get('licenseId'))
                            ->where('area', $slug)
                            ->update([
                                'json' => $_POST['json']
                            ]);


                        if ($status){
                            redirect(siteUrl('design-settings/menu-settings'))
                                ->with('Menü değişiklikleri başarıyla kaydedildi')
                                ->send();
                            return '';
                        } else {
                            redirect(siteUrl('design-settings/menu-settings'))
                                ->with('Veritabanında güncelleme yapılırken bir sorun oluştu')
                                ->send();
                            return '';
                        }
                    }
                }


                $data = Manager::table('menu')
                    ->where('license', auth()->get('licenseId'))
                    ->where('area', $slug)
                    ->get()
                    ->all();


                if (empty($data)){
                    Manager::table('menu')
                        ->insert([
                            'license' => auth()->get('licenseId'),
                            'area' => $slug,
                            'json' => '[]'
                        ]);

                    $setData = [];
                } else {
                    $setData = $data[0];
                }

                return $this->view('design-settings.edit-menu-settings', [
                    'slug' => $slug,
                    'data' => $setData
                ]);
            } else {
                redirect(siteUrl('design-settings/menu-settings'))
                    ->send();
                return '';
            }

        }

        public function sliderSettings(Request $request, Response $response): string
        {
            return $this->view('design-settings.slider-settings');
        }

        public function newSlider(Request $request, Response $response): string
        {
            if ($request->getMethod() == 'POST'){
                echo "<pre>";
                print_r($_POST);
                echo "</pre>";
            }
            return $this->view('design-settings.new-slider');
        }
	}