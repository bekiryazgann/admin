@extends('layouts.layout')
@section('title', trans('Slider Ayarları'))
@section('content')
    <div class="content-header">

    </div>
    <div class="content-body">
        <form method="POST">
            <div class="card">
                <div class="card-body row">
                    <div class="col-12 row align-items-end">
                        <div class="mb-2 col-6">
                            <label for="slider_title" class="form-label"> Slider Başlığı </label>
                            <input type="text" name="slider_title" id="slider_title" class="form-control" placeholder="Açılış alanı slider'ı">
                        </div>
                        <div class="mb-2 col-6 d-flex justify-content-end">
                            <button class="btn btn-primary" type="button" id="newSlide">
                                <i class="fas fa-plus"></i>
                                <span> Yeni Slide </span>
                            </button>
                        </div>
                    </div>
                    <div class="col-12 row mt-5">
                        <div class="col-12 row" style="gap: 20px 0">
                            <div class="col-4">
                                <label class="form-label" for="slider_image"> Görsel </label>
                                <input type="file" name="slider_image" class="form-control" id="slider_image">
                            </div>

                            <div class="col-4">
                                <label class="form-label" for="slider_description"> Açıklama </label>
                                <input type="text" name="slider_description" class="form-control" placeholder="Açıklama" id="slider_description">
                            </div>

                            <div class="col-2">
                                <label class="form-label" for="slider_link"> Bağlantı </label>
                                <input type="text" name="slider_link" class="form-control" placeholder="https://socore.net" id="slider_link">
                            </div>

                            <div class="col-2 d-flex align-items-end">
                                <button class="btn btn-danger w-100" type="button">
                                    <i class="fas fa-trash"></i>
                                    <span> Sil </span>
                                </button>
                            </div>

                            <div class="col-2">
                                <div class="form-check form-check-primary form-switch">
                                    <input type="checkbox" checked="" class="form-check-input no-size" id="slide_active" name="slide_active">
                                    <label for="slide_active" class="form-label"> Aktif </label>
                                </div>
                            </div>

                            <div class="col-2">
                                <div class="form-check form-check-primary form-switch">
                                    <input type="checkbox" class="form-check-input no-size" id="slide_target" name="slide_target">
                                    <label for="slide_target" class="form-label"> Bağlantıyı Yeni Sekmede Aç </label>
                                </div>
                            </div>
                        </div>

                        <div style="padding-left: calc(var(--bs-gutter-x) * .5);">
                            <hr>
                        </div>

                    </div>
                </div>
            </div>
        </form>
    </div>
@endsection
@section('styles')

@endsection
@section('scripts')
    <script src="{{siteUrl('assets/js/pages/new-slider.js')}}"></script>
@endsection