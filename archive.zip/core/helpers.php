<?php

	/**
	 * @param String $key
	 * @param String $default
	 * @return mixed
	 */
	function sysConfig(string $key, string $default = ''): mixed
	{
		\Arrilot\DotEnv\DotEnv::load(dirname(__DIR__) . '/.env.php');
		return \Arrilot\DotEnv\DotEnv::get($key, $default);
	}

	/**
	 * @param $name
	 * @return false|string
	 */
	function cookie($name): false|string
	{
		if (isset($_COOKIE[$name])) {
			return rawurldecode($_COOKIE[$name]);
		}
		return false;
	}


	/**
	 * @param $url
	 * @return \Core\Redirect
	 */
	function redirect($url = null): \Core\Redirect
	{
		return \Core\Redirect::getInstance($url);
	}

	/**
	 * @param string|null $url
	 * @param string|null $msg
	 * @return void
	 */
	function redirectTo(string $url = null, string $msg = null): void
	{
		if ($msg == null) {
			redirect($url)->send();
		} else {
			redirect($url)->with($msg)->send();
		}
	}

	/**
	 * @param $name
	 * @return array|false|string|string[]
	 */
	function post($name): array|false|string
	{
		if (isset($_POST[$name])) {
			if (is_array($_POST[$name])) {
				return array_map(function ($item) {
					return htmlspecialchars(strip_tags(trim($item)));
				}, $_POST[$name]);
			}
			return htmlspecialchars(strip_tags(trim($_POST[$name])));
		}
		return false;
	}

	/**
	 * @param $name
	 * @return array|false|string|string[]
	 */
	function get($name): array|false|string
	{
		if (isset($_GET[$name])) {
			if (is_array($_GET[$name])) {
				return array_map(function ($item) {
					return htmlspecialchars(strip_tags(trim($item)));
				}, $_GET[$name]);
			}
			return htmlspecialchars(strip_tags(trim($_GET[$name])));
		}
		return false;
	}

	/**
	 * @return \Carbon\Carbon
	 */
	function carbon(): \Carbon\Carbon
	{
		return new \Carbon\Carbon();
	}


    /**
     * @param String $path
     * @return string
     */
    function siteUrl(string $path = ''): string
    {
        return sysConfig('BASE_URL') . '/admin/' . $path;
    }

    function imageUrl(string $path = ''): string
    {
        return sysConfig('BASE_URL') . '/' . $path;
    }

	/**
	 * @param $path
	 * @return string
	 */
	function themeAssets($path): string
	{
		return sysConfig('BASE_URL') . '/' . 'themes/' . sysConfig('THEME') . '/assets/' . $path;
	}

	/**
	 * @return \Core\Auth
	 */
	function auth(): \Core\Auth
	{
		return \Core\Auth::getInstance();
	}

	/**
	 * @return \Core\Csrf
	 */
	function xssToken(): \Core\Csrf
	{
		return new \Core\Csrf();
	}

	/**
	 * @return string
	 */
	function csrf_field(): string
	{
		return "<input type=\"hidden\" class=\"form-control\" name=\"_token\" value=\"" . xssToken()->getToken() . "\" />";
	}

	/**
	 * @param $name
	 * @return \Core\Upload
	 */
	function upload($name): \Core\Upload
	{
		return \Core\Upload::getInstance($name);
	}

	/**
	 * @param $url
	 * @return \Core\Slug
	 */
	function slug($url): \Core\Slug
	{
		return \Core\Slug::getInstance($url);
	}

	/**
	 * @param String $key
	 * @param Array $params
	 * @return String
	 */
	function trans(string $key, array $params = []): string
	{
		$translate = new \Core\Translate(sysConfig('LOCALE', 'fr'));
		return $translate->translate($key, $params);
	}

	/**
	 * @param array|object $elements
	 * @param int $id
	 * @return array
	 */
	function buildCategory(array|object $elements, int $id = 0): array
	{
		$branch = [];
		foreach ($elements as $element){
			if ($element->top == $id){
				$child = buildCategory($elements, $element->id);

				if ($child){
					$element->child = $child;
				} else {
					$element->child = [];
				}

				$branch[] = $element;
			}
		}
		return json_decode(json_encode($branch), true);
	}

	/**
	 * @param $elements
	 * @param int $id
	 * @param int $counter
	 * @param string $prefix
	 * @return array
	 */
	function listArray($elements, int $id = 0, int $counter = 0, string $prefix = ''): array
	{
		static $array = [];
		foreach ($elements as $element) {
			if ($element->top == $id) {
				$array[$element->id] = [
					'name' => str_starts_with(((!$prefix == '') ? $prefix . ' → ' : '') . $element->name, ' → ') ? substr_replace(((!$prefix == '') ? $prefix . ' → ' : '') . $element->name, '', '1', '4') : ((!$prefix == '') ? $prefix . ' → ' : '') . $element->name,
					'data' => $element
				];
				listArray($elements, $element->id, $counter + 3, $prefix . ' → ' . $element->name);
			}
		}
		return $array;
	}

        /**
         * @param string $paragraph
         * @param int $word
         * @param string|null $overflow
         * @return string
         */
    function shorter(string $paragraph, int $word = 5, ?string $overflow = '...'): string
    {
        $data = explode(' ', $paragraph);
        $count = count($data);

        if ($count <= $word) {
            return $paragraph;
        }

        $shortened = implode(' ', array_slice($data, 0, $word));

        if ($overflow !== null) {
            $shortened .= $overflow;
        }

        return $shortened;
    }

    function xml_decode(string $xml): array
    {
        $new = simplexml_load_string($xml);
        $con = json_encode($new);
        return json_decode($con, true);
    }

    function minifyJs($js): string
    {
        if (trim($js) === "") return $js;
        return preg_replace(
            array(
                '#\s*("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\')\s*|\s*\/\*(?!\!|@cc_on)(?>[\s\S]*?\*\/)\s*|\s*(?<![\:\=])\/\/.*(?=[\n\r]|$)|^\s*|\s*$#',
                '#("(?:[^"\\\]++|\\\.)*+"|\'(?:[^\'\\\\]++|\\\.)*+\'|\/\*(?>.*?\*\/)|\/(?!\/)[^\n\r]*?\/(?=[\s.,;]|[gimuy]|$))|\s*([!%&*\(\)\-=+\[\]\{\}|;:,.<>?\/])\s*#s',
                '#;+\}#',
                '#([\{,])([\'])(\d+|[a-z_][a-z0-9_]*)\2(?=\:)#i',
                '#([a-z0-9_\)\]])\[([\'"])([a-z_][a-z0-9_]*)\2\]#i'
            ),
            array(
                '$1',
                '$1$2',
                '}',
                '$1$3',
                '$1.$3'
            ),
            $js);
    }