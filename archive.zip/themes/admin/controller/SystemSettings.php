<?php
	
	namespace themes\admin\controller;
	
	use Core\Controller;
    use Illuminate\Database\Capsule\Manager;
    use Symfony\Component\HttpFoundation\Request;

    class SystemSettings extends Controller
	{
        /**
         * @param Request $request
         * @return string
         */
		public function corporateInformation(Request $request): string
        {
            if ($request->getMethod() == 'POST'){
                $this->validator->rule('required', [
                    'brand-logo',
                    'company-name',
                    'tax-id',
                    'tax-office',
                    'address',
                    'district',
                    'province',
                    'country',
                    'phone',
                    'email',
                ]);
                if ($this->validator->validate() && xssToken()->isVerify()){

                    $image = upload('brand-logo')
                        ->convert('webp')
                        ->to('upload/brand-logo');

                    if ($error = $image->error()){
                        echo "<pre>";
                        print($error);
                        echo "</pre>";
                        die;
                    }

                    # TODO: bütün işlemler tamam ama sadece veritabanında tablo oluşturulacak.s
                    /*
                    $status = Manager::table('a')
                        ->insert([
                            'company-name' => post('company-name'),
                            'tax-id' => post('tax-id'),
                            'tax-office' => post('tax-office'),
                            'address' => post('address'),
                            'district' => post('district'),
                            'province' => post('province'),
                            'country' => post('country'),
                            'phone' => post('phone'),
                            'email' => post('email')
                        ]);
                    */
                    $status = true;
                    if ($status){
                        redirect(siteUrl('settings/system-settings/corporate-information'))
                            ->with('Değişiklikler başarıyla kaydedildi!')
                            ->send();
                    } else {
                        redirect(siteUrl('settings/system-settings/corporate-information'))
                            ->with('Değişiklikler veritabanına işlenirken bir hata oluştu!')
                            ->send();
                    }
                }
            }
            return $this->view('system-settings.corporate-information');
        }

        /**
         * @param Request $request
         * @return string
         */
        public function currencySettings(Request $request): string
        {
            return $this->view('system-settings.currency-settings');
        }

        public function taxSettings(Request $request): string
        {
            return $this->view('system-settings.tax-settings');
        }
	}