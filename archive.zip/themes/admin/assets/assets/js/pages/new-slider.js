(function () {
    let newSlideButton = document.querySelector('#newSlide');

    newSlideButton.addEventListener('click', e => {
        console.log('tamammmmm....')
    })
})()