<?php $__env->startSection('title', trans('Menu Yönetimi')); ?>
<?php $__env->startSection('content'); ?>
    <div class="content-header row">
        <div class="content-header-left col-md-9 col-12 mb-2">
            <div class="row breadcrumbs-top">
                <div class="col-12">
                    <h2 class="content-header-title float-start mb-0"><?php echo trans("Menüler") ?></h2>
                    <div class="breadcrumb-wrapper">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item">
                                <a href="<?php echo e(siteUrl()); ?>"><?php echo trans("Yönetim Paneli") ?></a>
                            </li>
                            <li class="breadcrumb-item">
                                <?php echo trans("Tasarım Ayarları") ?>
                            </li>
                            <li class="breadcrumb-item">
                                <?php echo trans("Menüler") ?>
                            </li>
                        </ol>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <div class="content-body">
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title"> Menüler </h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <div class="col-6">
                                <a class="card shadow-none border cursor-pointer btn btn-primary"
                                   href="<?php echo e(siteUrl('design-settings/menu-settings/edit/header')); ?>">
                                    <div class="card-body d-flex align-items-center justify-content-center">
                                        Header Menü
                                    </div>
                                </a>
                            </div>
                            <div class="col-6">
                                <a class="card shadow-none border cursor-pointer btn btn-primary"
                                   href="<?php echo e(siteUrl('design-settings/menu-settings/edit/footer')); ?>">
                                    <div class="card-body d-flex align-items-center justify-content-center">
                                        Footer Menü
                                    </div>
                                </a>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Users/bekir/Desktop/admin/themes/admin/views/design-settings/menuSettings.blade.php ENDPATH**/ ?>