<script src="{{siteUrl('first-data-load')}}"></script>
<script src="{{themeAssets('bundle.js')}}"></script>